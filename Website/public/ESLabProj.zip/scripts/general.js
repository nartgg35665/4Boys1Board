class User{
    constructor(imglink,name,surname,id,password){
        this.imglink = imglink;
        this.name = name;
        this.surname = surname;
        this.id = id;
        this.password = password;
    }
}

var users = [new User("img/nart.jpg","Ratchanart","Lacharochana","001","1234"), new User("img/asia.jpg","Theerut","Seekeaw","002","1234"), new User("img/plub.jpg","Chaiyapluek","Muskul","003","1234"), new User("img/yuan.jpg","None","Wanitchollakit","004","1234")]