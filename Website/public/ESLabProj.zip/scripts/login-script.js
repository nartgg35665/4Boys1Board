const formEL = document.getElementById('form');
const infoEl = document.getElementById('info');

const chooseUser = JSON.parse(localStorage.getItem("user"));
formEL.innerHTML = `<img src="${chooseUser.imglink}"> <span id="name">${chooseUser.name} ${chooseUser.surname}</span><label for="password">Password</label>
<input type="password" id="password" placeholder="Enter password" required />
<input type="submit" value="Login">`

const passwordEl = document.getElementById('password');

formEL.addEventListener("submit",(e)=>{
    e.preventDefault();
    login();
});

async function login(){
    let checkLoginComplete = false;
    if(users){
        users.forEach(user => {
            console.log(user[0]);
            if(user.id === chooseUser.id && chooseUser.password === passwordEl.value){
                checkLoginComplete = true;
                window.location.href = "temperature.html";
            }
        });
    }
    if(!checkLoginComplete){
        infoEl.innerHTML = "Wrong password.";
    }
}